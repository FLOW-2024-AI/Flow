"""
Lambda Function: Invoice Processor con AWS Bedrock
Trigger: S3 ObjectCreated
Flow: S3 PDF → Bedrock Claude 3.5 Sonnet → DynamoDB

Modelo: Claude 3.5 Sonnet v2 (mejor para documentos financieros)
"""

import json
import boto3
import os
import base64
from datetime import datetime
from decimal import Decimal

# AWS Clients
s3_client = boto3.client('s3')
bedrock_runtime = boto3.client('bedrock-runtime')
dynamodb = boto3.resource('dynamodb')

# Environment variables
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'Facturas-dev')
table = dynamodb.Table(TABLE_NAME)

# Bedrock model - Claude 3.5 Sonnet v2 (mejor para facturación)
MODEL_ID = "anthropic.claude-3-5-sonnet-20241022-v2:0"


def lambda_handler(event, context):
    """
    Main handler - triggered by S3 upload
    """
    try:
        # 1. Get S3 event info
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        file_size = record['s3']['object']['size']
        
        print(f"📄 Processing: s3://{bucket}/{key}")
        print(f"📦 Size: {file_size} bytes")
        
        # 2. Extract client_id from path
        parts = key.split('/')
        client_id = parts[0] if len(parts) > 0 else 'unknown'
        
        print(f"👤 Client ID: {client_id}")
        
        # 3. Download PDF from S3
        print("📥 Downloading PDF from S3...")
        pdf_obj = s3_client.get_object(Bucket=bucket, Key=key)
        pdf_bytes = pdf_obj['Body'].read()
        
        # Convert to base64 for Bedrock
        pdf_base64 = base64.standard_b64encode(pdf_bytes).decode('utf-8')
        
        print(f"📦 PDF encoded: {len(pdf_base64)} characters")
        
        # 4. Call Bedrock Claude to analyze invoice
        print("🤖 Calling Bedrock Claude 3.5 Sonnet...")
        
        invoice_data = analyze_invoice_with_bedrock(pdf_base64)
        
        print(f"✅ Claude completed - Invoice: {invoice_data.get('numeroFactura')}")
        
        # 5. Build DynamoDB item
        dynamo_item = build_item(client_id, invoice_data, bucket, key, file_size)
        
        # 6. Save to DynamoDB
        print("💾 Saving to DynamoDB...")
        table.put_item(Item=dynamo_item)
        
        print(f"✅ SUCCESS - Invoice ID: {dynamo_item['invoiceId']}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Invoice processed successfully',
                'invoiceId': dynamo_item['invoiceId'],
                'clientId': client_id,
                'total': float(invoice_data.get('montos', {}).get('total', 0)),
                'numeroFactura': invoice_data.get('numeroFactura')
            })
        }
        
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'type': type(e).__name__
            })
        }


def analyze_invoice_with_bedrock(pdf_base64):
    """
    Send PDF to Claude via Bedrock and get structured JSON
    Uses expert prompt for maximum accuracy
    """
    
    # Prompt de contador experto peruano
    expert_prompt = """Eres un Contador Público Colegiado peruano con 15 años de experiencia en auditoría tributaria y facturación electrónica. 

Eres experto en:
- Normativa SUNAT y sistema de comprobantes de pago electrónicos (CPE)
- Ley del IGV (Decreto Legislativo N° 821)
- Reglamento de Comprobantes de Pago (Resolución de Superintendencia N° 007-99/SUNAT)
- Validación de documentos tributarios según estándares peruanos

Tu tarea es analizar esta factura electrónica peruana con máxima precisión y extraer TODOS los datos en formato JSON estructurado.

ESTRUCTURA JSON REQUERIDA (retorna SOLO este JSON, sin texto adicional):

{
  "numeroFactura": "F006-0171739",
  "serie": "F006",
  "correlativo": "0171739",
  "tipoComprobante": "FACTURA",
  "fechaEmision": "2025-09-22",
  "horaEmision": "10:30:00",
  
  "emisor": {
    "tipoDocumento": "RUC",
    "numeroDocumento": "20517482472",
    "razonSocial": "CORPORACION LIDER PERU S.A.",
    "nombreComercial": null,
    "direccion": "Calle Leoncio Prado 446 - SURQUILLO - LIMA",
    "ubigeo": null,
    "departamento": "LIMA",
    "provincia": "LIMA",
    "distrito": "SURQUILLO",
    "telefono": "924956748",
    "email": "ventas@corporacionliderperu.com",
    "web": "www.corporacionliderperu.com"
  },
  
  "receptor": {
    "tipoDocumento": "RUC",
    "numeroDocumento": "20604163642",
    "razonSocial": "EL HELADERO S.A.C.",
    "direccion": "AV. MARISCAL ELOY URETA 185 URB. EL PINO",
    "departamento": "LIMA",
    "provincia": "LIMA",
    "distrito": "SAN LUIS"
  },
  
  "montos": {
    "moneda": "PEN",
    "tipoMoneda": "SOLES",
    "subtotal": 1305.17,
    "descuentoGlobal": 0.00,
    "baseImponible": 1305.17,
    "igv": 234.93,
    "igvPorcentaje": 18.00,
    "isc": 0.00,
    "icbper": 0.00,
    "otrosTributos": 0.00,
    "percepcion": 0.96,
    "percepcionPorcentaje": 2.00,
    "retencion": 0.00,
    "detraccion": 0.00,
    "opGravadas": 1305.17,
    "opExoneradas": 0.00,
    "opInafectas": 0.00,
    "opGratuitas": 0.00,
    "anticipos": 0.00,
    "redondeo": 0.00,
    "total": 1540.10,
    "montoTotal": 1541.06,
    "totalLetras": "MIL QUINIENTOS CUARENTA Y 10/100 SOLES"
  },
  
  "items": [
    {
      "linea": 1,
      "codigo": "BEB0094",
      "codigoSunat": null,
      "cantidad": 6.000,
      "unidadMedida": "UNI",
      "descripcion": "CIELO AGUA MINERAL X 7 LT SIN GAS",
      "valorUnitario": 6.78,
      "precioUnitario": 8.00,
      "descuento": 0.00,
      "valorVenta": 40.68,
      "igv": 7.32,
      "icbper": 0.00,
      "total": 48.00,
      "tipoAfectacion": "GRAVADO"
    }
  ],
  
  "condiciones": {
    "formaPago": "CONTADO",
    "medioPago": "TRANSFERENCIA",
    "plazoCredito": null,
    "cuotas": null,
    "vendedor": "CHRISTIAN",
    "numeroPedido": "0006-2849",
    "ordenCompra": null,
    "guiaRemision": null,
    "observaciones": "NO ACEPTAMOS DEVOLUCIONES NI CAMBIOS DESPUES DE 48 HORAS"
  },
  
  "datosBancarios": [
    {
      "banco": "BCP",
      "tipoCuenta": "CORRIENTE",
      "moneda": "PEN",
      "numeroCuenta": "194-2522444-0-31",
      "cci": "002-19400252244403190",
      "titular": "CORPORACION LIDER PERU SA"
    },
    {
      "banco": "SCOTIABANK",
      "tipoCuenta": "CORRIENTE",
      "moneda": "PEN",
      "numeroCuenta": "000-6309240",
      "cci": "009-29000006309240-57",
      "titular": "CORPORACION LIDER PERU SA"
    }
  ],
  
  "sunat": {
    "codigoHash": null,
    "firmaDigital": null,
    "qr": null,
    "urlConsulta": "https://cpe.facilerp.com/comprobantes/consultar/20517482472",
    "sistemaEmision": "FACILERP",
    "autorizacionSunat": "034-005-007244/SUNAT",
    "agenteRetencion": true,
    "resolucionAgenteRetencion": "R.S.186-2023",
    "tipoOperacion": "VENTA_INTERNA",
    "leyendas": [
      "Operación Sujeta al 2.00% de Percepción del IGV"
    ]
  },
  
  "validaciones": {
    "rucEmisorValido": true,
    "rucReceptorValido": true,
    "formatoNumeroFacturaValido": true,
    "fechaValida": true,
    "igvCalculoCorrecto": true,
    "totalCalculoCorrecto": true,
    "serieValida": true,
    "todosItemsTienenCodigo": true,
    "warnings": [],
    "errores": []
  }
}

INSTRUCCIONES CRÍTICAS:

1. VALIDACIONES MATEMÁTICAS:
   - IGV debe ser exactamente subtotal * 0.18 (tolerancia ±0.50 por redondeo)
   - Total debe ser: subtotal + IGV + ICBPER + percepción - descuentos
   - Suma de items debe coincidir con subtotal
   - Si hay diferencias, reportar en validaciones.warnings

2. FORMATO DE DATOS:
   - RUC: exactamente 11 dígitos numéricos
   - Números SIN comillas: usar float o int
   - Fechas: formato YYYY-MM-DD
   - Hora: formato HH:MM:SS (si no existe, usar null)
   - Montos: máximo 2 decimales
   - Si un campo no existe: usar null (NO string vacío)

3. EXTRACCIÓN DE ITEMS:
   - Extraer TODOS los productos/servicios listados
   - Incluir códigos de producto si existen
   - Calcular valor unitario sin IGV si solo aparece precio con IGV
   - Identificar tipo de afectación (GRAVADO/EXONERADO/INAFECTO/GRATUITO)

4. DATOS BANCARIOS:
   - Extraer TODAS las cuentas bancarias mencionadas
   - Identificar tipo de cuenta (CORRIENTE/AHORRO/DETRACCION)
   - Incluir CCI si está disponible

5. VALIDACIONES SUNAT:
   - Verificar que RUC tenga 11 dígitos
   - Verificar formato de serie (letra + 3 dígitos)
   - Validar que correlativo sea numérico
   - Identificar si es agente de retención/percepción

6. WARNINGS Y ERRORES:
   - En validaciones.warnings: inconsistencias menores (ej: IGV difiere por redondeo)
   - En validaciones.errores: problemas graves (ej: RUC inválido, total no cuadra)

7. RESPUESTA:
   - Retornar ÚNICAMENTE el JSON
   - NO agregar texto explicativo antes o después
   - NO usar markdown (```json)
   - JSON válido y bien formateado

Analiza la factura con máximo rigor profesional y precisión contable.
"""
    
    # Construir request para Bedrock
    request_body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 8000,
        "temperature": 0.1,  # Baja temperatura para mayor precisión
        "top_p": 0.9,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "document",
                        "source": {
                            "type": "base64",
                            "media_type": "application/pdf",
                            "data": pdf_base64
                        }
                    },
                    {
                        "type": "text",
                        "text": expert_prompt
                    }
                ]
            }
        ]
    }
    
    try:
        # Call Bedrock
        print(f"🔄 Invoking Bedrock model: {MODEL_ID}")
        
        response = bedrock_runtime.invoke_model(
            modelId=MODEL_ID,
            body=json.dumps(request_body)
        )
        
        # Parse response
        response_body = json.loads(response['body'].read())
        
        # Extract text from Claude response
        content = response_body.get('content', [])
        if not content:
            raise ValueError("Empty response from Bedrock")
        
        response_text = content[0].get('text', '')
        
        print(f"📝 Claude response length: {len(response_text)} chars")
        
        # Extract JSON from response
        # Claude might add explanatory text, so we extract the JSON block
        json_start = response_text.find('{')
        json_end = response_text.rfind('}') + 1
        
        if json_start == -1 or json_end == 0:
            print(f"⚠️ Response text: {response_text[:500]}")
            raise ValueError("No JSON found in Claude response")
        
        invoice_json = response_text[json_start:json_end]
        
        # Parse JSON
        invoice_data = json.loads(invoice_json)
        
        print(f"✅ Successfully parsed invoice data")
        print(f"📊 Items extracted: {len(invoice_data.get('items', []))}")
        print(f"💰 Total: {invoice_data.get('montos', {}).get('total', 0)}")
        
        # Check validations
        validations = invoice_data.get('validaciones', {})
        if validations.get('warnings'):
            print(f"⚠️ Warnings: {validations['warnings']}")
        if validations.get('errores'):
            print(f"❌ Errors: {validations['errores']}")
        
        return invoice_data
        
    except json.JSONDecodeError as e:
        print(f"❌ JSON parse error: {str(e)}")
        print(f"Response text: {response_text[:1000]}")
        raise ValueError(f"Invalid JSON from Claude: {str(e)}")
        
    except Exception as e:
        print(f"❌ Bedrock invocation error: {str(e)}")
        raise


def build_item(client_id, invoice_data, bucket, key, file_size):
    """
    Build DynamoDB item from Claude's structured response
    """
    
    # Generate invoice ID
    ruc = invoice_data.get('emisor', {}).get('numeroDocumento', 'UNKNOWN')
    numero = invoice_data.get('numeroFactura', 'UNKNOWN')
    invoice_id = f"{ruc}-{numero}"
    
    # Get date
    fecha = invoice_data.get('fechaEmision', datetime.now().strftime('%Y-%m-%d'))
    
    # Convert all floats to Decimal for DynamoDB
    def convert_to_decimal(obj):
        """Recursively convert floats to Decimal for DynamoDB"""
        if isinstance(obj, dict):
            return {k: convert_to_decimal(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_decimal(i) for i in obj]
        elif isinstance(obj, float):
            return Decimal(str(obj))
        return obj
    
    invoice_data_decimal = convert_to_decimal(invoice_data)
    
    # Build DynamoDB item
    item = {
        # Primary keys
        'PK': f'CLIENT#{client_id}',
        'SK': f'INVOICE#{fecha}#{invoice_id}',
        
        # Identifiers
        'clientId': client_id,
        'invoiceId': invoice_id,
        'numeroFactura': invoice_data.get('numeroFactura'),
        'tipoComprobante': invoice_data.get('tipoComprobante', 'FACTURA'),
        
        # Flat fields for queries
        'fechaEmision': fecha,
        'emisorRUC': ruc,
        'emisorRazonSocial': invoice_data.get('emisor', {}).get('razonSocial'),
        'receptorRUC': invoice_data.get('receptor', {}).get('numeroDocumento'),
        'receptorRazonSocial': invoice_data.get('receptor', {}).get('razonSocial'),
        'total': Decimal(str(invoice_data.get('montos', {}).get('total', 0))),
        'moneda': invoice_data.get('montos', {}).get('moneda', 'PEN'),
        
        # Complete structured data from Claude (with Decimals)
        'data': invoice_data_decimal,
        
        # S3 metadata
        'archivo': {
            's3Bucket': bucket,
            's3Key': key,
            's3Url': f's3://{bucket}/{key}',
            'nombreArchivo': key.split('/')[-1],
            'tamanoBytes': file_size
        },
        
        # Processing metadata
        'procesamiento': {
            'status': 'processed',
            'motor': 'bedrock-claude',
            'modelId': MODEL_ID,
            'modelName': 'Claude 3.5 Sonnet v2',
            'confidence': 'high',
            'timestampProcesado': datetime.utcnow().isoformat() + 'Z',
            'warnings': invoice_data.get('validaciones', {}).get('warnings', []),
            'errores': invoice_data.get('validaciones', {}).get('errores', [])
        },
        
        # Validations from Claude
        'validado': {
            'igvCorrecto': invoice_data.get('validaciones', {}).get('igvCalculoCorrecto', False),
            'totalCorrecto': invoice_data.get('validaciones', {}).get('totalCalculoCorrecto', False),
            'rucValido': invoice_data.get('validaciones', {}).get('rucEmisorValido', False),
            'requiereRevision': len(invoice_data.get('validaciones', {}).get('errores', [])) > 0
        },
        
        # GSI keys
        'GSI1PK': f'EMISOR#{ruc}',
        'GSI1SK': fecha,
        
        # Audit trail
        'audit': {
            'creadoEn': datetime.utcnow().isoformat() + 'Z',
            'creadoPor': 'bedrock-claude-processor',
            'versionDocumento': 1
        }
    }
    
    return item